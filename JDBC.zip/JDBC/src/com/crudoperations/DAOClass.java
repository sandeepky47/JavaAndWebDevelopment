package com.crudoperations;

import java.sql.*;

public class DAOClass {

	public void insert(int roll, String name, String standard, String date, int fee)
			throws Exception, ClassNotFoundException {

		String url = "jdbc:mysql://localhost:3306/student";
		String username = "root";
		String pass = "test";
		String query = "insert into student values(?,?,?,?,?)";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setInt(1, roll);
		st.setString(2, name);
		st.setString(3, standard);
		st.setDate(4, java.sql.Date.valueOf(date));
		st.setInt(5, fee);
		int row = st.executeUpdate();
		if (row > 0) {
			System.out.println("Record Inserted Successfully");
		}

		st.close();
		con.close();

	}

	public void display(int rollno) throws Exception, ClassNotFoundException {
		String url = "jdbc:mysql://localhost:3306/student";
		String username = "root";
		String pass = "test";
		String query = "select * from student where rollno=?";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setInt(1, rollno);
		ResultSet res = st.executeQuery();

		while (res.next()) {
			int roll = res.getInt(1);
			String name = res.getString("studentname");
			String standard = res.getString("standard");
			Date date = res.getDate(4);
			int fee = res.getInt(5);
			System.out.println("Student details:");
			System.out.println(roll + " ," + name + " ," + standard + " ," + date + " ," + fee);
		}

		st.close();
		con.close();

	}

	public void delete(int rollno) throws Exception, ClassNotFoundException {

		String url = "jdbc:mysql://localhost:3306/student";
		String username = "root";
		String pass = "test";
		String query = "delete from student where rollno=?";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setInt(1, rollno);
		int row = st.executeUpdate();
		if (row > 0) {
			System.out.println("Record Deleted successfully");
		}

		st.close();
		con.close();

	}

	public void modify(int rollno) throws Exception, ClassNotFoundException {
		String url = "jdbc:mysql://localhost:3306/student";
		String username = "root";
		String pass = "test";
		String query = "update student set fees=? where rollno=?";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setInt(1, 5500);
		st.setInt(2, rollno);
		int row = st.executeUpdate();
		if (row > 0) {
			System.out.println("Record Updated successfully");
		}

		st.close();
		con.close();

	}

	public void recepit(int rollno) throws Exception, ClassNotFoundException {

		String url = "jdbc:mysql://localhost:3306/student";
		String username = "root";
		String pass = "test";
		String query = "select * from student where rollno=?";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		PreparedStatement st = con.prepareStatement(query);
		st.setInt(1, rollno);
		ResultSet res = st.executeQuery();

		res.next();
		int fee = res.getInt("fees");
		String name = res.getString("StudentName");
		System.out.println("\nABC International School\n" + "Date: 2020-08-20" + "\n\nReceived with thanks from " + name
				+ " , Rs." + fee + "  towards payment of fees for the month of March.");

		st.close();
		con.close();

	}

	public void display() throws Exception, ClassNotFoundException {
		String url = "jdbc:mysql://localhost:3306/student";
		String username = "root";
		String pass = "test";
		String query = "select * from student";

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, username, pass);
		PreparedStatement st = con.prepareStatement(query);
		ResultSet res = st.executeQuery();

		System.out.println("\nStudent Table:");
		while (res.next()) {
			int roll = res.getInt(1);
			String name = res.getString("studentname");
			String standard = res.getString("standard");
			Date date = res.getDate(4);
			int fee = res.getInt(5);
			System.out.println(roll + " ," + name + " ," + standard + " ," + date + " ," + fee);
		}

		st.close();
		con.close();

	}
}
