package com.crudoperations;

import java.util.Date;

public class JDBCCalls {

	public static void main(String[] args) throws ClassNotFoundException, Exception {

		int n = Integer.parseInt(args[0]);
		int roll = Integer.parseInt(args[1]);

		DAOClass dao = new DAOClass();
		switch (n) {
		case 1:
			String name = args[2];
			String standard = args[3];
			String date = args[4];
			int fee = Integer.parseInt(args[5]);
			dao.insert(roll, name, standard, date, fee);
			break;
		case 2:
			dao.delete(roll);
			break;
		case 3:
			dao.modify(roll);
			break;
		case 4:
			dao.display(roll);
			break;
		case 5:
	   	dao.recepit(roll);
			break;
		default:
			System.out.println("Wrong input");
		}
		/*
		 * DAOClass dao=new DAOClass(); dao.display(101); //dao.insert();
		 * //dao.modify(102); //dao.delete(104); dao.recepit(101); dao.display();
		 */

	}

}
