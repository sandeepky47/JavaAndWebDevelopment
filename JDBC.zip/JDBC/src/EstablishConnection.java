import java.sql.*;

public class EstablishConnection {

	public static void main(String[] args) throws Exception ,ClassNotFoundException{

		String url="jdbc:mysql://localhost:3306/fitnessdatabase";
		String username="root";
		String pass="test";
		String query="select first_name from user where id=1";
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con= DriverManager.getConnection(url, username, pass);
		 Statement st=con.createStatement();
		 ResultSet res=st.executeQuery(query);
		 res.next();
		 String out=res.getString("first_name");
		 System.out.println(out);
		 
		 st.close();
		 con.close();
	}

}
