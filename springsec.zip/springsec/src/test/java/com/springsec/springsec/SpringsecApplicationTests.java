package com.springsec.springsec;

import com.springsec.main.SpringsecApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes= SpringsecApplication.class)
class SpringsecApplicationTests {
	@Test
	void contextLoads() {
	}
}
