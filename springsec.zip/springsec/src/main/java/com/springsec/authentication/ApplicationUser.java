package com.springsec.authentication;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.springsec.model.User;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class ApplicationUser implements UserDetails {



	private static final long serialVersionUID = 1L;
	private User user;

    private Set<? extends GrantedAuthority> grantedAuthorities;
    private String username;
    private String password;
    private String email;
    private boolean isAccountNonExpired;
    private boolean isAccountNonLocked;
    private boolean isCredentialsNonExpired;
    private boolean isEnabled;
	
	public ApplicationUser(User user) {
		this.user = user;
	}

    public ApplicationUser(String username, String password, String email, Set<? extends GrantedAuthority> grantedAuthorities, boolean isAccountNonExpired, boolean isAccountNonLocked, boolean isCredentialsNonExpired, boolean isEnabled) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.grantedAuthorities = grantedAuthorities;
        this.isAccountNonExpired = isAccountNonExpired;
        this.isAccountNonLocked = isAccountNonLocked;
        this.isCredentialsNonExpired = isCredentialsNonExpired;
        this.isEnabled = isEnabled;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
    	List<GrantedAuthority> localGrantedAuthorities = new ArrayList<>();
    	this.user.getRoleList().forEach(p -> {
    		GrantedAuthority authority = new SimpleGrantedAuthority(p);
    		localGrantedAuthorities.add(authority);
    	});
    	
    	this.user.getPermissionList().forEach(p -> {
    		GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + p);
    		localGrantedAuthorities.add(authority);
    	});
        return grantedAuthorities;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getPassword() {
        return this.user.getPassword();
    }

    @Override
    public String getUsername() {
        return this.user.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return this.user.getisAccountNonExpired();
    }

    @Override
    public boolean isAccountNonLocked() {
        return this.user.getisAccountNonLocked();
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return this.user.getisCredentialsNonExpired();
    }

    @Override
    public boolean isEnabled() {
        return this.user.getisEnabled();
    }

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
