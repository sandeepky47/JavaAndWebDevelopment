package com.springsec.authentication;

import com.springsec.model.User;
import com.springsec.repo.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class ApplicationUserService implements UserDetailsService {

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;

    Logger log = LoggerFactory.getLogger(ApplicationUserService.class);

    public ApplicationUserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        User testUser = new User("user", passwordEncoder.encode("user"), "ishaan.meena005@gmail.com" ,
                true, true, true,
                true, "ADMIN", "student:read, student:write, course:read, course:write");
        setupUser(testUser);
    }

    //Testing the repository with test user. Login {username : user, password : user}
    public void setupUser(User newUser){
        newUser.setPassword(passwordEncoder.encode(newUser.getPassword()));
        newUser.setRoles("USER");
        newUser.setPermissions("student:read, student:write, course:read, course:write");
        newUser.setAccountNonExpired(true);
        newUser.setAccountNonLocked(true);
        newUser.setCredentialsNonExpired(true);
        newUser.setEnabled(true);
        userRepository.save(newUser);
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        if(!doesUserExistAlready(username))
        {
           log.warn(String.format("User %s does not exist in the database.", username));
            throw new UsernameNotFoundException(String.format("User %s not found", username));
        }
        return new ApplicationUser(userRepository.findByUsername(username));
    }

    public boolean doesUserExistAlready(String username){
        User user = userRepository.findByUsername(username);
        return user != null;
    }
}
