package com.springsec.authentication;

import com.google.common.collect.Lists;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import static com.springsec.security.ApplicationUserRole.*;

@Repository("AbstractDAO")
public class AbstractApplicationUserDAOService implements ApplicationUserDAO {

    @Autowired
    public AbstractApplicationUserDAOService(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Optional<ApplicationUser> selectApplicationUserByUsername(String username) {
        return getApplicationUsers()
                .stream()
                .filter(applicationUser -> username.equals(applicationUser.getUsername()))
                .findFirst();
    }

    private final PasswordEncoder passwordEncoder;

    private List<ApplicationUser> getApplicationUsers() {
        List<ApplicationUser> applicationUsers;
        applicationUsers = Lists.newArrayList(
                new ApplicationUser(
                        "user",
                        passwordEncoder.encode("user"),
                        "ishaan.meena005@gmail.com",
                        STUDENT.getGrantedAuthorities(),
                        true,
                        true,
                        true,
                        true),
                new ApplicationUser(
                        "mod",
                        passwordEncoder.encode("mod"),
                        "ishaan.meena005@gmail.com",
                        MOD.getGrantedAuthorities(),
                        true,
                        true,
                        true,
                        true),
                new ApplicationUser(
                        "admin",
                        passwordEncoder.encode("admin"),
                        "ishaan.meena005@gmail.com",
                        ADMIN.getGrantedAuthorities(),
                        true,
                        true,
                        true,
                        true),
                new ApplicationUser(
                        "xyz",
                        passwordEncoder.encode("xyz"),
                        "ishaan.meena005@gmail.com",
                        XYZ.getGrantedAuthorities(),
                        true,
                        true,
                        true,
                        true)
            );
        return applicationUsers;
    }
}