package com.springsec.services;

import com.springsec.model.SpaService;
import com.springsec.repo.ServiceRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SpaStuffService {
    ServiceRepository serviceRepository;
    SpaStuffService(ServiceRepository serviceRepository){
        this.serviceRepository = serviceRepository;
    }
    public List<SpaService> getAllServicesProvided() {
        return serviceRepository.findAll();
    }
}
