package com.springsec.services;
import com.springsec.model.Reservation;
import com.springsec.repo.ReservationRepository;
import org.springframework.stereotype.Service;

@Service
public class ReservationService {

    private ReservationRepository reservationRepository;

    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    public boolean setupReservation(Reservation reservation){
        reservationRepository.save(reservation);
        return true;
    }
}
