package com.springsec.repo;

import com.springsec.model.SpaService;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface ServiceRepository extends CrudRepository<SpaService, Long> {
    ArrayList<SpaService> findAll();
}

