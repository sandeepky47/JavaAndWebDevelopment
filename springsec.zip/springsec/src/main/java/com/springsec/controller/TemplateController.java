package com.springsec.controller;

import com.springsec.authentication.ApplicationUserService;
import com.springsec.model.Reservation;
import com.springsec.model.SpaService;
import com.springsec.model.User;
import com.springsec.services.ReservationService;
import com.springsec.services.SpaStuffService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(path = "/")
public class TemplateController {

    private ApplicationUserService applicationUserService;
    private ReservationService reservationService;
    private SpaStuffService spaStuffService;

    public TemplateController(ApplicationUserService applicationUserService, ReservationService reservationService, SpaStuffService spaStuffService){
        this.applicationUserService = applicationUserService;
        this.reservationService = reservationService;
        this.spaStuffService = spaStuffService;
    }

    @GetMapping("index")
    public String index(){
        return "index";
    }

    @GetMapping("login")
    public String getLoginView(Model model){
        model.addAttribute("User", new User());
        return "login";
    }

    @PostMapping("login")
    public String postLoginView(Model model, BindingResult bindingResult){
        if (bindingResult.hasErrors()) {
            return "login";
        }
        return "index";
    }

    @GetMapping("register")
    public String getRegisterView(Model model){
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("register")
    public String postRegisterView(@Valid User user, Model model, BindingResult bindingResult){
        model.addAttribute("user", user);
        model.addAttribute("existedUsername", null);
        if (bindingResult.hasErrors()) {
            return "register";
        }
        if(applicationUserService.doesUserExistAlready(user.getUsername())){
            model.addAttribute("usernameExistBool",true);
            return "register";
        }
        if(applicationUserService.doesUserExistAlready(user.getEmail())){
            model.addAttribute("emailExistBool",true);
            return "register";
        }
        applicationUserService.setupUser(user);
        return "redirect:index";
    }

    @GetMapping("book")
    public String takeAppointment(@Valid Reservation reservation, Model model){
        model.addAttribute("reservation", reservation);
        List<SpaService> serviceList = spaStuffService.getAllServicesProvided();
        model.addAttribute("serviceList", serviceList);
        return "book";
    }

    @PostMapping("book")
    public String bookAppointment(@Valid Reservation reservation, Model model, BindingResult bindingResult){
        model.addAttribute("reservation", reservation);
        reservationService.setupReservation(reservation);
        return "book";
    }

    @GetMapping("error")
    public String error404(){
        return "error";
    }


}
