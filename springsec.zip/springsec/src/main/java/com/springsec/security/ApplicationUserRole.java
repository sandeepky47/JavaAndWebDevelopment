package com.springsec.security;

import java.util.Set;
import java.util.stream.Collectors;

import com.google.common.collect.Sets;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.springsec.security.ApplicationUserPermissions.*;

public enum ApplicationUserRole {

	STUDENT(Sets.newHashSet()),
	ADMIN(Sets.newHashSet(ApplicationUserPermissions.COURSE_READ, ApplicationUserPermissions.COURSE_WRITE,
			ApplicationUserPermissions.STUDENT_READ, ApplicationUserPermissions.STUDENT_WRITE)),
	MOD(Sets.newHashSet(ApplicationUserPermissions.COURSE_READ, ApplicationUserPermissions.STUDENT_READ)),
	XYZ(Sets.newHashSet(ApplicationUserPermissions.STUDENT_READ));

	private final Set<ApplicationUserPermissions> permissions;

	ApplicationUserRole(Set<ApplicationUserPermissions> permissions)
	{
		this.permissions = permissions;
	}

	public Set<ApplicationUserPermissions> getPermissions() {
		return permissions;
	}

	public Set<SimpleGrantedAuthority> getGrantedAuthorities() {
		Set<SimpleGrantedAuthority> permissions = getPermissions().stream()
				.map(permission -> new SimpleGrantedAuthority(permission.getPermission()))
				.collect(Collectors.toSet());
		permissions.add(new SimpleGrantedAuthority("ROLE_" + this.name()));
		System.out.println(permissions);
		return permissions;
	}
}
