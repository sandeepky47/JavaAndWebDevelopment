package com.springsec.model;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    long orderId;
    @Column(nullable = false)
    String username;
    @Column(nullable = false)
    String serviceType;
    @Column(nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    Date date;
    @Column(nullable = false)
    String time;
    @Column
    String msg;
    @Column(nullable = false)
    int status;


    public Reservation() {
    }

    public Reservation(String username, String serviceType, Date date, String time, String msg, int status) {
        this.username = username;
        this.serviceType = serviceType;
        this.date = date;
        this.time = time;
        this.msg = msg;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "bookedBy='" + username + '\'' +
                ", serviceType='" + serviceType + '\'' +
                ", date=" + date +
                ", time='" + time + '\'' +
                ", msg='" + msg + '\'' +
                ", status=" + status +
                '}';
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String bookedBy) {
        this.username = bookedBy;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
