package com.springsec.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SpaService {
    @Id
    long serviceId;
    @Column(nullable = false)
    String title;
    @Column(nullable = false)
    String description;

    public SpaService() {
    }

    public SpaService(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public long getServiceId() {
        return serviceId;
    }

    public void setServiceId(long serviceId) {
        this.serviceId = serviceId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String desc) {
        this.description = desc;
    }
}
