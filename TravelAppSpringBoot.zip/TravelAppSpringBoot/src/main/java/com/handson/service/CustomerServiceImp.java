package com.handson.service;

import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.handson.model.Customer;
import com.handson.model.User;

@Component
public class CustomerServiceImp implements CustomerService {

	private JdbcTemplate jdbcTemplate;

	public CustomerServiceImp(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private List<Customer> list;

	@Override
	public List<Customer> getAllCustomer() {
		list = new ArrayList<Customer>();
		String query = "select * from customer";
		list = jdbcTemplate.query(query, BeanPropertyRowMapper.newInstance(Customer.class));
		return list;
	}
	
	@Override
	public Customer getCustomerById(int id) {

		String query = "select * from customer where customer_id=" + id;
		return jdbcTemplate.queryForObject(query, BeanPropertyRowMapper.newInstance(Customer.class));
     
	}

	@Override
	public void deleteCustomer(int id) {

		String query = "DELETE FROM customer WHERE customer_id=?";
		jdbcTemplate.update(query, id);
	}

	@Override
	public void modifyCustomer(Customer customer) {

		String query = "UPDATE customer SET customer_name=?, email=?,contact=?,gender=? WHERE customer_id=?";
		jdbcTemplate.update(query, customer.getCustomerName(),customer.getEmail(),customer.getContact(),customer.getGender(),customer.getCustomerId());
	}


	@Override
	public boolean validateUser(User user) {
		String query = "select count(*) from user where username=? and password=?";
		int count=jdbcTemplate.queryForObject(query, new Object[] {user.getUsername(),user.getPassword()},Integer.class);
		return count>0?true:false;
	}

	@Override
	public void addCustomer(Customer customer) {
		
		String query = "INSERT INTO customer(customer_name,email,contact,gender)"+" VALUES (?,?,?,?)";
		jdbcTemplate.update(query, customer.getCustomerName(),customer.getEmail(),customer.getContact(),customer.getGender());
	}

	@Override
	public boolean validateEmail(Customer customer) {
		String query = "select count(*) from customer where email=?";
		int count=jdbcTemplate.queryForObject(query, new Object[] {customer.getEmail()},Integer.class);
		return count>0?true:false;
	}

	@Override
	public boolean sameEmail(Customer customer) {
		String query = "select * from customer where customer_id=" + customer.getCustomerId();
		Customer cust=jdbcTemplate.queryForObject(query, BeanPropertyRowMapper.newInstance(Customer.class));
		if(customer.getEmail().equalsIgnoreCase(cust.getEmail())) {
			return true;
		}
		else {
			return false;
		}
	}

	
}
