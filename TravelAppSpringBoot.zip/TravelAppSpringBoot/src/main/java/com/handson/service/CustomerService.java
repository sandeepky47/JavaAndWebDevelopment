package com.handson.service;

import java.util.List;

import com.handson.model.Customer;
import com.handson.model.User;

public interface CustomerService {

	public List<Customer> getAllCustomer();

	public Customer getCustomerById(int id) ;

	public void deleteCustomer(int id);

	public void modifyCustomer(Customer customer);
	
	public boolean validateUser(User user);
	
	public void addCustomer(Customer customer);
	
	public boolean validateEmail(Customer customer);
	
	public boolean sameEmail(Customer customer);
	
}
