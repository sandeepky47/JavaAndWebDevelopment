package com.handson.model;

import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

public class Customer {
	
	private int customerId;
	@NotBlank
	private String customerName;
	@NotBlank
	@Email                                         //  /\w+([\.]?\w+)*@\w+(\.\w{3})+$/         //sandeep.kumar@gmail.org
	private String email;
	@NotBlank
	@Pattern(regexp="[0-9]{10}",message="Contact must be of 10 digits")           
	private String contact;
	@NotBlank
	private String gender;
	@NotNull
	@Past
	@DateTimeFormat(pattern="yyyy-MM-dd")
    private Date dateOfBirth;
	@NotBlank
	private String country; 
	public Customer() {

	}

	public Customer(int customerId, String customerName, String email, String contact, String gender) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.contact = contact;
		this.gender = gender;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
