package com.handson.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.handson.model.Customer;
import com.handson.model.User;
import com.handson.service.CustomerServiceImp;

@Controller
public class CustomerController {

	@Autowired(required = true)
	CustomerServiceImp customerimp;

	@GetMapping("/getallcustomer")
	public ModelAndView getAllDetails() {
		List<Customer> customerlist = customerimp.getAllCustomer();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("getAll");
        mv.addObject("customerlist", customerlist);
		return mv;
	}

	@PostMapping("/getbyid")
	public ModelAndView getOneDetails(HttpServletRequest request, HttpServletResponse response) 
			 {
		int custid = Integer.parseInt(request.getParameter("customer"));
		Customer custobj = customerimp.getCustomerById(custid);
		int temp = custobj.getCustomerId();
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("getOne");
		mv.addObject("custid", custobj.getCustomerId());
		mv.addObject("custname", custobj.getCustomerName());
		mv.addObject("email", custobj.getEmail());
		mv.addObject("contact", custobj.getContact());
		mv.addObject("gender", custobj.getGender());
		return mv;
	}

	@GetMapping("/addcustomer")
	public String addtourgetmethod(Model model) {
       model.addAttribute("customer", new Customer());
		return "addCustomer";
	}
	

	@PostMapping("/adding")
	public String addtourpostmethod(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Model model) {
		String page="getAll";
		if(result.hasErrors()) {
	            page="addCustomer";
	        }
		 else if(customerimp.validateEmail(customer)) {
			 model.addAttribute("existerror", "This EmailId already exists");
			 page="addCustomer";
		 }
		 else {
			 customerimp.addCustomer(customer);
			 List<Customer> customerlist = customerimp.getAllCustomer();
		   	    model.addAttribute("customerlist", customerlist);
			  page="getAll";
		 }
		return page;
	}

	@GetMapping("/deleterequest")
	public String deleterequest(HttpServletRequest request, HttpServletResponse response,Model model) {
	String custid = request.getParameter("id");
	model.addAttribute("customerid", custid);
		return "deleteRequest";

	}  

	@GetMapping("/deleterecord")
	public String deletegetmethod(HttpServletRequest request, HttpServletResponse response,Model model) {
		int custid = Integer.parseInt(request.getParameter("id"));
		customerimp.deleteCustomer(custid);
		
		 List<Customer> customerlist = customerimp.getAllCustomer();
	   	    model.addAttribute("customerlist", customerlist);
		return "getAll";

	}

	@GetMapping("/editrecord")
	public String edittourgetmethod(HttpServletRequest request, HttpServletResponse response,Model model)
			 {
		int custid = Integer.parseInt(request.getParameter("id"));
		Customer custobj = customerimp.getCustomerById(custid);
		model.addAttribute("customer", custobj);
		return "editCustomer";
		
	
	}
	

	@PostMapping("/editing")
	public String edittourpostmethod(HttpServletRequest request, HttpServletResponse response,Model model) {

		int custid = Integer.parseInt(request.getParameter("customerid"));
		String custname = request.getParameter("customername");
		String email = request.getParameter("email");
		String contact = request.getParameter("contact");
		String gender = request.getParameter("gender");
		   Customer custobj=new Customer();
		   custobj.setCustomerId(custid);
		   custobj.setCustomerName(custname);
		   custobj.setEmail(email);
		   custobj.setContact(contact);
		   custobj.setGender(gender);
		   if(!Pattern.matches("[0-9]{10}",contact)) {
				model.addAttribute("contacterror", "Must be 10 digit number");
				model.addAttribute("customer", custobj);
				return "editCustomer";
			}
		   else if(customerimp.sameEmail(custobj)) {
			    customerimp.modifyCustomer(custobj);
				List<Customer> customerlist = customerimp.getAllCustomer();
		   	    model.addAttribute("customerlist", customerlist);
					return "getAll";
		   }
		   else if(customerimp.validateEmail(custobj)) {
				 model.addAttribute("emailerror", "This EmailId already exists");
				 model.addAttribute("customer", custobj);
				 return "editCustomer";
			 }
		   else {
		customerimp.modifyCustomer(custobj);
		List<Customer> customerlist = customerimp.getAllCustomer();
   	    model.addAttribute("customerlist", customerlist);
			return "getAll";
		   }
	
		
	}

	@ExceptionHandler(EmptyResultDataAccessException.class)
	public ModelAndView excetionHandler() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		mv.addObject("message", "Invalid Tour ID");
		return mv;

	}


	@PostMapping("/loginform")
	public String loginpostmethod(@Valid @ModelAttribute("user") User user, BindingResult result,Model model) {
       String page="home";
	    if(result.hasErrors()) {
	            page="login";
	        }
	    else if(customerimp.validateUser(user) ){
	    	List<Customer> customerlist = customerimp.getAllCustomer();
	    	 model.addAttribute("customerlist", customerlist);
	    	page="getAll";
	    }
		 else {
			 model.addAttribute("errormsg", "Invalid Username/Password");
			  page="login";
		 }
	return page;  
	}
	
	@GetMapping("/cancel")
	public String cancelmethod(Model model) {
		List<Customer> customerlist = customerimp.getAllCustomer();
   	 model.addAttribute("customerlist", customerlist);
		return "getAll";
	}
	
	@ModelAttribute(name="countries")
	public List<String> getAllCountry(Model model) {
		List<String> countrylist = new ArrayList<>();
		countrylist.add("India");
		countrylist.add("Bhutan");
		countrylist.add("China");
		countrylist.add("Canada");
   	 return countrylist;
	}

}
