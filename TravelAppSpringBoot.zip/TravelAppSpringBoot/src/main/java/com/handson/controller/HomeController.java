package com.handson.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import com.handson.model.User;

@Controller
public class HomeController {
	
	@GetMapping("/")
	public String getLoginPage(Model model, HttpServletRequest request) {
		model.addAttribute("user", new User());
		return "login";
	}
	
	@GetMapping("/home")
	public String getHomePage(ModelMap map, HttpServletRequest request) {
		return "home";
	}

}
