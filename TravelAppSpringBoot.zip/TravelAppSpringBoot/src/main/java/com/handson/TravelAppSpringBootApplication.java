package com.handson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAppSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelAppSpringBootApplication.class, args);
	}

}
