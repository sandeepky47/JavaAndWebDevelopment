package com.example.demo.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CustomerDao;
import com.example.demo.model.Customer;

@Service
public class CustomerServiceImp implements CustomerService {
	
	@Autowired
	private CustomerDao custdao;

	@Override
	public List<Customer> getAllCustomer() {
         return custdao.getAllCustomer();
	}

	@Override
	public void addCustomer(Customer customer) {
		custdao.addCustomer(customer);

	}

}
