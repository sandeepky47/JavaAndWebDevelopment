package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Customer;



public interface CustomerService {

	public List<Customer> getAllCustomer();

	public void addCustomer(Customer customer);
	

	
	
	
}
