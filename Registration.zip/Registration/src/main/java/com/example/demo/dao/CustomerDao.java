package com.example.demo.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.demo.model.Customer;

@Component
public class CustomerDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public CustomerDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private List<Customer> list;

	public List<Customer> getAllCustomer() {
		list = new ArrayList<Customer>();
		String query = "select * from customer";
		list = jdbcTemplate.query(query, BeanPropertyRowMapper.newInstance(Customer.class));
		return list;
	}
	
	public void addCustomer(Customer customer) {
		
	String query = "INSERT INTO customer(first_name,last_name,email,password,gender,dateofbirth,country,hobbies)"+" VALUES (?,?,?,?,?,?,?,?)";
	jdbcTemplate.update(query, customer.getFirstName(),customer.getLastName(),customer.getEmail(),
	customer.getPassword(),customer.getGender(),customer.getDateOfBirth(),customer.getCountry(),Arrays.toString(customer.getHobbies()));
	}

}
