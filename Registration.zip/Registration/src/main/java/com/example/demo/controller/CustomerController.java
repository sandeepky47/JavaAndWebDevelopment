package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Customer;
import com.example.demo.service.CustomerServiceImp;


@Controller
public class CustomerController {
	
	@Autowired(required = true)
	CustomerServiceImp customerimp;

	@GetMapping("/")
	public String getregistrationPage(Model model, HttpServletRequest request) {
		model.addAttribute("customer", new Customer());
		return "registrationPage";
	}
	
	@ModelAttribute(name="countries")
	public List<String> getAllCountry(Model model) {
		List<String> countrylist = new ArrayList<>();
		countrylist.add("India");
		countrylist.add("Bhutan");
		countrylist.add("China");
		countrylist.add("Canada");
   	 return countrylist;
	}
	
	@PostMapping("/adding")
	public String addtourpostmethod(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Model model) {
		String page="getAll";
		if(result.hasErrors()) {
	            page="registrationPage";
	        }
		 else if(!customer.getPassword().equals(customer.getConfirmPassword())) {
			 model.addAttribute("passworderror", "Password and confirm password must be same");
			 page="registrationPage";
		 }
		 else {
			 customerimp.addCustomer(customer);
			 List<Customer> customerlist = customerimp.getAllCustomer();
		   	    model.addAttribute("customerlist", customerlist);
			  page="getAll";
			  
			/*  model.addAttribute("customerobj", customer);
			  page="errorcheck"; */
		 }
		return page;
	}
}
